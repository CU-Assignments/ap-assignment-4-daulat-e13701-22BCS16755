class Solution {
    public int[] beautifulArray(int n) {
        if(n == 1) return new int[]{1};
        int[] odd = beautifulArray((n + 1) / 2);
        int[] even = beautifulArray(n / 2);
        
        int[] res = new int[n];
        int index = 0;
        for (int x : odd) {
            res[index++] = 2 * x - 1;
        }
        for (int x : even) {
            res[index++] = 2 * x;
        }
        
        return res;
    }
}
