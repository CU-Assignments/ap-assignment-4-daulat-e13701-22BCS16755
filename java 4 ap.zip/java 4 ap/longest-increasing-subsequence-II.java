import java.util.*;

class Solution {
    public int lengthOfLIS(int[] nums, int k) {
        int maxVal = 0;
        for (int num : nums) {
            maxVal = Math.max(maxVal, num);
        }
        
        SegmentTree segTree = new SegmentTree(maxVal + 1);
        int maxLength = 0;
        
        for (int num : nums) {
            int left = Math.max(0, num - k);
            int maxPrevLIS = segTree.query(left, num - 1);
            int newLIS = maxPrevLIS + 1;
            segTree.update(num, newLIS);
            maxLength = Math.max(maxLength, newLIS);
        }
        
        return maxLength;
    }

    static class SegmentTree {
        int[] tree;
        int size;

        public SegmentTree(int size) {
            this.size = size;
            tree = new int[4 * size];
        }

        public void update(int index, int value) {
            update(0, 0, size - 1, index, value);
        }

        private void update(int node, int start, int end, int index, int value) {
            if (start == end) {
                tree[node] = Math.max(tree[node], value);
                return;
            }
            int mid = (start + end) / 2;
            if (index <= mid) {
                update(2 * node + 1, start, mid, index, value);
            } else {
                update(2 * node + 2, mid + 1, end, index, value);
            }
            tree[node] = Math.max(tree[2 * node + 1], tree[2 * node + 2]);
        }

        public int query(int left, int right) {
            if (left > right) return 0;
            return query(0, 0, size - 1, left, right);
        }

        private int query(int node, int start, int end, int left, int right) {
            if (right < start || left > end) return 0;
            if (left <= start && end <= right) return tree[node];
            int mid = (start + end) / 2;
            return Math.max(query(2 * node + 1, start, mid, left, right),
                            query(2 * node + 2, mid + 1, end, left, right));
        }
    }
}
