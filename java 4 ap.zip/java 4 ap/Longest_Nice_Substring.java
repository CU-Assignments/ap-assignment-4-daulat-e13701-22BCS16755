class Solution {
    public String longestNiceSubstring(String s) {
      int stringLength = s.length();
      int start = -1;
      int maxLength = 0;
      for (int i = 0; i < stringLength; ++i) {
        int lower=0,upper=0;
        for (int j = i; j < stringLength; ++j) {
            char currentChar = s.charAt(j);
        if (Character.isLowerCase(currentChar)) {
                    lower |= 1 << (currentChar - 'a');
                }
        else {
                    upper |= 1 << (currentChar - 'A');
                }
        if (lower == upper && maxLength < j - i + 1) {
            maxLength = j - i + 1;
                    start = i;
                }
    }
}
          return (start == -1) ? "" : s.substring(start, start + maxLength);
    }
}