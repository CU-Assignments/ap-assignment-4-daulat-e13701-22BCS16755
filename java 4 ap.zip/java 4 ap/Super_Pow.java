class Solution {
    private static final int MOD = 1337;
    
    public int superPow(int a, int[] b) {
        a %= MOD; 
        return modPow(a, b, MOD);
    }

    private int modPow(int a, int[] b, int mod) {
        int result = 1;
        for (int digit : b) {
            result = (modExp(result, 10, mod) * modExp(a, digit, mod)) % mod;
        }
        return result;
    }

    private int modExp(int base, int exp, int mod) {
        int res = 1;
        while (exp > 0) {
            if (exp % 2 == 1) {
                res = (res * base) % mod;
            }
            base = (base * base) % mod;
            exp /= 2;
        }
        return res;
    }
}
